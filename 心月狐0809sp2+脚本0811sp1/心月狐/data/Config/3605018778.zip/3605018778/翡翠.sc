[{
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	11371,
		"script":	"�������",
		"task":	0
	}, {
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	20760,
		"script":	"ִ���Զ��л���ɫ",
		"task":	0
	}]