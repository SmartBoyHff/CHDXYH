[{
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	19844,
		"script":	"�������",
		"task":	0
	}, {
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	14305,
		"script":	"ִ���Զ��л���ɫ",
		"task":	0
	}]