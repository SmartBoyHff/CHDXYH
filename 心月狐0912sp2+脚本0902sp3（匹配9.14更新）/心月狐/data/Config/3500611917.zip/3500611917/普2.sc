[{
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	17443,
		"script":	"��������",
		"task":	0
	}, {
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	24678,
		"script":	"ִ���Զ��л���ɫ",
		"task":	0
	}]