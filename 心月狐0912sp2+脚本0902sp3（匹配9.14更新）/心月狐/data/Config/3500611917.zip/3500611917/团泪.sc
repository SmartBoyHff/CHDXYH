[{
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	26282,
		"script":	"ŵ���֮��",
		"task":	0
	}, {
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	453,
		"script":	"ִ���Զ��л���ɫ",
		"task":	0
	}]