[{
		"setcount":	1,
		"setcounttype":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	28989,
		"script":	"��ӣ����",
		"task":	0
	}, {
		"setcount":	0,
		"setcounttype":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	14549,
		"script":	"ִ���Զ��л���ɫ",
		"task":	0
	}]