[{
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	17188,
		"script":	"����ϲֿ�",
		"task":	0
	}, {
		"setcount":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	5942,
		"script":	"ִ���Զ��л���ɫ",
		"task":	0
	}]