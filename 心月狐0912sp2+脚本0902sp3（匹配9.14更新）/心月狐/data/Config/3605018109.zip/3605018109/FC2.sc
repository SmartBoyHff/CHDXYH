[{
		"setcount":	0,
		"setreward":	1,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	21450,
		"script":	"�������",
		"task":	0
	}, {
		"setcount":	0,
		"setreward":	1,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	10061,
		"script":	"ִ���Զ��л���ɫ",
		"task":	0
	}]