[{
		"setcount":	1,
		"setcounttype":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"����",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	3118,
		"script":	"��ӣ����",
		"task":	0
	}, {
		"setcount":	0,
		"setcounttype":	0,
		"setreward":	true,
		"loadtime":	0,
		"diyitem":	"",
		"diyproperty":	"",
		"diyother":	"",
		"diyawaken":	"",
		"tag":	21794,
		"script":	"ִ���Զ��л���ɫ",
		"task":	0
	}]